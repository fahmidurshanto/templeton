export default function HomeHero() {
    return (
        <div className="text-center">
            <h1 className="text-5xl font-bold text-gradient-gold mb-4">Welcome to Hutchinson</h1>
            <p className="text-xl text-gray-500">The gateway to the Partnership Portal</p>
        </div>
    )
}
